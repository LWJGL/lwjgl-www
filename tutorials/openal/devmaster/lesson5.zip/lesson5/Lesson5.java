/* 
 * Copyright (c) 2004 LWJGL Project
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are 
 * met:
 * 
 * * Redistributions of source code must retain the above copyright 
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'LWJGL' nor the names of 
 *   its contributors may be used to endorse or promote products derived 
 *   from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;
import org.lwjgl.test.openal.WaveData;

/**
 * $Id$
 * <p>
 * Lesson 3: Multiple Sources
 * </p>
 * @author Brian Matzon <brian@matzon.dk>
 * @version $Revision$
 */
public class Lesson5 {
  
  /** Index of thunder sound */
  public static final int THUNDER = 0;
  
  /** Index of waterdrop sound */
  public static final int WATERDROP = 1;
  
  /** Index of stream sound */
  public static final int STREAM = 2;
  
  /** Index of rain sound */
  public static final int RAIN = 3;
  
  /** Index of chimes sound */
  public static final int CHIMES = 4;
  
  /** Index of ocean sound */
  public static final int OCEAN = 5;  

  /** Maximum data buffers we will need. */
  public static final int NUM_BUFFERS = 6;
  
	/** Buffers hold sound data. */
  IntBuffer buffer = BufferUtils.createIntBuffer(NUM_BUFFERS);

  /** Sources are points emitting sound. */
  IntBuffer source = BufferUtils.createIntBuffer(128);
  
  /** Position of the source sound. */
  FloatBuffer sourcePos = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0f, 0.0f, 0.0f });

  /*
   * These are 3D cartesian vector coordinates. A structure or class would be
   * a more flexible of handling these, but for the sake of simplicity we will
   * just leave it as is.
   */  
  
  /** Velocity of the source sound. */
  FloatBuffer sourceVel = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0f, 0.0f, 0.0f });

  /** Position of the listener. */
  FloatBuffer listenerPos = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0f, 0.0f, 0.0f });

  /** Velocity of the listener. */
  FloatBuffer listenerVel = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0f, 0.0f, 0.0f });

  /** Orientation of the listener. (first 3 elements are "at", second 3 are "up")
      Also note that these should be units of '1'. */
  FloatBuffer listenerOri = BufferUtils.createFloatBuffer(6).put(new float[] { 0.0f, 0.0f, -1.0f,  0.0f, 1.0f, 0.0f });
  
  public Lesson5() {
  	// CRUCIAL!
    // any buffer that has data added, must be flipped to establish its position and limits
    sourcePos.flip();
    sourceVel.flip();
    listenerPos.flip();
    listenerVel.flip();
    listenerOri.flip();
  }
  
  /**
   * boolean LoadALData()
   *
   *  This function will load our sample data from the disk using the Alut
   *  utility and send the data into OpenAL as a buffer. A source is then
   *  also created to play that buffer.
   */
  int loadALData() {
    // Load wav data into a buffers.
    AL10.alGenBuffers(buffer);

    if(AL10.alGetError() != AL10.AL_NO_ERROR)
      return AL10.AL_FALSE;

    WaveData waveFile = WaveData.create("thunder.wav");
    AL10.alBufferData(buffer.get(THUNDER), waveFile.format, waveFile.data, waveFile.samplerate);
    waveFile.dispose();
    
    waveFile = WaveData.create("waterdrop.wav");
    AL10.alBufferData(buffer.get(WATERDROP), waveFile.format, waveFile.data, waveFile.samplerate);
    waveFile.dispose();

    waveFile = WaveData.create("stream.wav");
    AL10.alBufferData(buffer.get(STREAM), waveFile.format, waveFile.data, waveFile.samplerate);
    waveFile.dispose();
    
    waveFile = WaveData.create("rain.wav");
    AL10.alBufferData(buffer.get(RAIN), waveFile.format, waveFile.data, waveFile.samplerate);
    waveFile.dispose();
    
    waveFile = WaveData.create("ocean.wav");
    AL10.alBufferData(buffer.get(OCEAN), waveFile.format, waveFile.data, waveFile.samplerate);
    waveFile.dispose();
    
    waveFile = WaveData.create("chimes.wav");
    AL10.alBufferData(buffer.get(CHIMES), waveFile.format, waveFile.data, waveFile.samplerate);
    waveFile.dispose();

    // Do another error check and return.
    if(AL10.alGetError() == AL10.AL_NO_ERROR)
      return AL10.AL_TRUE;

    return AL10.AL_FALSE;
  }
  
  /**
   * void AddSource(ALint type)
   *
   *  Will add a new water drop source to the audio scene.
   */
  private void addSource(int type) {
    int position = source.position();
    source.limit(position + 1);
    AL10.alGenSources(source);

    if(AL10.alGetError() != AL10.AL_NO_ERROR) {
      System.out.println("Error generating audio source.");
      System.exit(-1);
    }

    AL10.alSourcei(source.get(position), AL10.AL_BUFFER,   buffer.get(type) );
    AL10.alSourcef(source.get(position), AL10.AL_PITCH,    1.0f             );
    AL10.alSourcef(source.get(position), AL10.AL_GAIN,     1.0f             );
    AL10.alSource (source.get(position), AL10.AL_POSITION, sourcePos        );
    AL10.alSource (source.get(position), AL10.AL_VELOCITY, sourceVel        );
    AL10.alSourcei(source.get(position), AL10.AL_LOOPING,  AL10.AL_TRUE     );

    AL10.alSourcePlay(source.get(position));
    
    // next index
    source.position(position+1);
  }  
  
  /**
   * void setListenerValues()
   *
   *  We already defined certain values for the Listener, but we need
   *  to tell OpenAL to use that data. This function does just that.
   */
  void setListenerValues() {
    AL10.alListener(AL10.AL_POSITION,    listenerPos);
    AL10.alListener(AL10.AL_VELOCITY,    listenerVel);
    AL10.alListener(AL10.AL_ORIENTATION, listenerOri);
  }  

  /**
   * void killALData()
   *
   *  We have allocated memory for our buffers and sources which needs
   *  to be returned to the system. This function frees that memory.
   */
  void killALData() {
    // set to 0, num_sources
    int position = source.position();
    source.position(0).limit(position);
    AL10.alDeleteSources(source);

    AL10.alDeleteBuffers(buffer);
  }
  
  public void execute() {
    // Initialize OpenAL and clear the error bit.
    try {
    	AL.create();
    } catch (LWJGLException le) {
    	le.printStackTrace();
      return;
    }
    AL10.alGetError();

    // Load the wav data.
    if(loadALData() == AL10.AL_FALSE) {
      System.out.println("Error loading data.");
      return;
    }

    setListenerValues();

    System.out.print("MindCode's OpenAL Lesson 5: Sources Sharing Buffers\n\n");
    System.out.print("Controls:\n");
    System.out.print("w) Water drops.\n");
    System.out.print("t) Rolling thunder.\n");
    System.out.print("s) Stream of trickling water.\n");
    System.out.print("r) Rain.\n");
    System.out.print("o) Lapping ocean waves.\n");
    System.out.print("c) Wind chimes.\n");
    System.out.print("q) Quit\n\n");    
    
    // Loop.
    char c = ' ';
    while (c != 'q') {
      try {
        c = (char) System.in.read();
      } catch (IOException ioe) {
        c = 'q';
      }

      switch (c) {
        case 'w': addSource(WATERDROP); break;
        case 't': addSource(THUNDER);   break;
        case 's': addSource(STREAM);    break;
        case 'r': addSource(RAIN);      break;
        case 'o': addSource(OCEAN);     break;
        case 'c': addSource(CHIMES);    break;
      }
    }    
    killALData();
  }
  
	public static void main(String[] args) {
    new Lesson5().execute();    
	}
}